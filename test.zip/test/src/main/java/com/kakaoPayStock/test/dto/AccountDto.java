package com.kakaoPayStock.test.dto;

import lombok.Data;

@Data
public class AccountDto {
   
	private String accountNo;
	private String accountName;
	private String branchCode;
	  
}