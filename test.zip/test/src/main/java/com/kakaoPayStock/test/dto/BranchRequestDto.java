package com.kakaoPayStock.test.dto;

import lombok.Data;

@Data
public class BranchRequestDto {
   
	private String brName;
	  
}